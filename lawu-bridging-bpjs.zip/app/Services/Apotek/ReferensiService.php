<?php

namespace App\Services\Apotek;

use App\Helpers\AppHelper;
use App\Repositories\Settings\Provider\ProviderRepositoryInterface;
use LZCompressor\LZString;

class ReferensiService
{
    public function __construct(
        ProviderRepositoryInterface $providerRepository
    )
    {
        $this->providerRepository = $providerRepository;
    }

    /**
     * Get All Data Apotek Referensi DPHO
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getDpho($request)
    {
        // Validate the Request Header
        if(!$request->header('x-consid')) return AppHelper::response_json(null, 400, 'Consumer ID tidak boleh kosong.');
        if(!$request->header('x-conspwd')) return AppHelper::response_json(null, 400, 'Consumer Password tidak boleh kosong.');
        if(!$request->header('x-userkey')) return AppHelper::response_json(null, 400, 'User Secret tidak boleh kosong.');

        // Request Data to BPJS
        $timestamp  = strtotime(date("Y-m-d H:i:s"));
        $response   = AppHelper::get_encrypt($request, $timestamp, 'apotek-rest-dev', 'referensi/dpho');

        // Declare Variable
        $key        = $request->header('x-consid') . $request->header('x-conspwd') . $timestamp;
        $string     = json_decode($response)->response;

        // Decrypt the Response from BPJS
        $json = AppHelper::get_decrypt($key, $string);

        return $json;
    }
}